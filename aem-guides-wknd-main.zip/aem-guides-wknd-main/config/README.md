# AEM as a Cloud Service Configuration Files

This folder contains service's configuration files that you can deploy on your AEM as a Cloud Service environment from Cloud Manager using Configuration Pipeline.

For now only CDN Traffic Filters Rules and WAF rules can be configured. You can learn more about Traffic Filters Rules and WAF rules in [our online documentation](https://experienceleague.adobe.com/docs/experience-manager-cloud-service/content/security/cdn-and-waf-rules.html).
