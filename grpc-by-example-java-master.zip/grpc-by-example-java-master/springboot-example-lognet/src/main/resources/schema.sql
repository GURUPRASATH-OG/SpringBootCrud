create table kv_table (
  key_column VARCHAR(100),
  key_value VARCHAR(256)
);
