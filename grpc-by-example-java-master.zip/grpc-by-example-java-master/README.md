gRPC Java Examples
==================

This is a collection of Java gRPC examples.

This is not official Google product.

[YouTube video](https://www.youtube.com/watch?v=xpmFhTMqWhc)
