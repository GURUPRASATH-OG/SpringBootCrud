package com.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Mobile

{
	@Id()
	private int id;
	private String name,brand;
	private int price,ram,rom;
	private Camera cam;
	
	
	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public Camera getCam() {
		return cam;
	}



	public void setCam(Camera cam) {
		this.cam = cam;
	}



	public Mobile()
	{
		
	}
	
	
	
	public Mobile(int id,String name, String brand, int price, int ram, int rom) 
	{
		super();
		this.id = id;
		this.name = name;
		this.brand = brand;
		this.price = price;
		this.ram = ram;
		this.rom = rom;
		
	}


	@Override
	public String toString() {
		return "Mobile [id=" + id + ", name=" + name + ", brand=" + brand + ", price=" + price + ", ram=" + ram
				+ ", rom=" + rom + "]";
	}



	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getRam() {
		return ram;
	}
	public void setRam(int ram) {
		this.ram = ram;
	}
	public int getRom() {
		return rom;
	}
	public void setRom(int rom) {
		this.rom = rom;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	
}
