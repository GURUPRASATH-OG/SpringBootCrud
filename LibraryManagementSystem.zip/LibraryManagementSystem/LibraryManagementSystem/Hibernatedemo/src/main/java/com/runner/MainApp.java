package com.runner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.entities.Camera;
import com.entities.Mobile;

public class MainApp {

	public static void main(String[] args) 
	
	{
		//creating a mobile object
		Mobile redmi = new Mobile(1,"note-20","redmi",30000,16,512);
		//now creating another class want to save this object in mobile entity table itself
		//so  we annotated Camera class with @Embeddable so that it camera fields in existing mobile table
		Camera cm = new Camera(12,"nikon","professional-camera");
		redmi.setCam(cm);
		
		Session session = getSession(Mobile.class);
		Transaction trans = session.beginTransaction();
		session.persist(redmi);
		var obj =  session.get(Mobile.class, 1);
		System.out.println(obj);
		trans.commit();
	}

	public static Session getSession(Class<?>... annotatedClasses) {
	    try {
	        // Create a new Configuration object
	        Configuration config = new Configuration().configure();
	        
	        // Dynamically add all annotated classes provided in varargs
	        for (Class<?> annotatedClass : annotatedClasses) {
	            config.addAnnotatedClass(annotatedClass);
	        }

	        // Build SessionFactory and open a Session
	        SessionFactory sessionFactory = config.buildSessionFactory();
	        return sessionFactory.openSession();
	    } catch (Exception e) {
	        e.printStackTrace();
	        throw new RuntimeException("Failed to open Hibernate session: " + e.getMessage());
	    }
	}


}
