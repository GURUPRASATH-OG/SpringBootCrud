package com.runner;

import com.entities.Laptop;
import com.entities.Student;

public class RelationApp {

	public static void main(String[] args) 
	{
		//creating a student entity object roll is primary key
		Student sudo = new Student();
		sudo.setGrade("A");
		sudo.setName("WalterWhite");
		sudo.setRollno(1);
		
		//creating object for laptop entity which has rollno as private key which is from the student entity
		//so we are setting the student object too. with the laptop object 
		//one laptop can be used by one student representing @OneToOne.
		Laptop lenevo = new Laptop();
		lenevo.setLid(110);
		lenevo.setLname("ThinKPad");
		lenevo.setStudent(sudo);
		
		//getting session for laptop nd studnet class
		var session = MainApp.getSession(Laptop.class,Student.class);
		session.beginTransaction();
		session.persist(lenevo);
		session.persist(sudo);
		session.getTransaction().commit();
	}

}
