package com.entities;

import jakarta.persistence.Embeddable;

@Embeddable
public class Camera 
{
	private int MegaPixel;
	private String cm_brand,cm_name;
	public Camera()
	{
		
	}
	public Camera(int megaPixel, String cm_brand, String name) {
		super();
		MegaPixel = megaPixel;
		this.cm_brand = cm_brand;
		this.cm_name = name;
	}
	public int getMegaPixel() {
		return MegaPixel;
	}
	public void setMegaPixel(int megaPixel) {
		MegaPixel = megaPixel;
	}
	public String getCm_brand() {
		return cm_brand;
	}
	public void setCm_brand(String cm_brand) {
		this.cm_brand = cm_brand;
	}
	public String getName() {
		return cm_name;
	}
	public void setName(String name) {
		this.cm_name = name;
	}
	@Override
	public String toString() {
		return "Camera [MegaPixel=" + MegaPixel + ", cm_brand=" + cm_brand + ", name=" + cm_name + "]";
	}
	
	
}
