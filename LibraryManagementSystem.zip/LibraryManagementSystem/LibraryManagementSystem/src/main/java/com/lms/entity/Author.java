package com.lms.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/*
 * using Lombok library for creating constuctors and getter and setter.
 */

@NoArgsConstructor
@Getter
@Setter
@ToString(includeFieldNames = true)// will include the fields name in to string.
@Entity
public class Author 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    @NotNull(message = "Author ID cannot be null")
	private Long id;
	@NotBlank(message = "Name is required")
	private String name;
	@NotBlank(message = "Awards is required")
	private String awards;
	
	
	
	public Author(String name, String awards) 
	{
		super();
		this.name = name;
		this.awards = awards;
		
	}
	/*
	 * One Author can write many books so OneToMany,
	 * mappedBy->tell that Author table don't create another (table) as mapping done by the Book Entity(table)
	 */
	@OneToMany(mappedBy = "author",cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<Books> writtenbooks;
	
	
	
	
}
