package com.lms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.dto.AuthorWithBooksDto;
import com.lms.dto.AuthorsDto;
import com.lms.dto.BooksDto;
import com.lms.service.AuthorService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("api/author")
public class AuthorController
{
	@Autowired 
	private AuthorService service;
	
	@PostMapping
	public ResponseEntity<AuthorsDto> addAuthor(@Valid @RequestBody AuthorsDto authordto)
	{
		
		authordto = service.addAuthor(authordto);
		return new ResponseEntity<>(authordto,HttpStatus.CREATED);
	}
	
	@PutMapping("{id}")
	public ResponseEntity<AuthorsDto> updateAuthor(@Valid @PathVariable Long id,@RequestBody AuthorsDto authordto)
	{
		authordto = service.updateAuthor(id, authordto);
		return new ResponseEntity<AuthorsDto>(authordto,HttpStatus.OK);
	}
	@GetMapping("{id}")
	public ResponseEntity<AuthorsDto> getAuthorByid(@Valid @PathVariable Long id)
	{
		AuthorsDto authordto = service.getAuthorById(id);
		return new ResponseEntity<>(authordto,HttpStatus.OK);
	}
	@GetMapping
	public ResponseEntity<List<AuthorsDto>> getAllAuthor()
	{
		List<AuthorsDto> list = service.getAllAuthors();
		return new ResponseEntity<>(list,HttpStatus.OK);
	}
	
	@DeleteMapping("{id}")
	public ResponseEntity<String> deletAuthorById(@Valid @PathVariable Long id)
	{
		 service.deleteAuthorById(id);
		return new ResponseEntity<>("Author deleted sucessfully",HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping
	public ResponseEntity<String> deleteAllAuthor()
	{
	     service.deleteAllAuthors();
		return new ResponseEntity<>("All authors deleted",HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/{authorId}/books")
    public AuthorWithBooksDto getAuthorWithBooks(@Valid @PathVariable Long authorId) {
        return service.getallBooks(authorId);
    }
	
}
