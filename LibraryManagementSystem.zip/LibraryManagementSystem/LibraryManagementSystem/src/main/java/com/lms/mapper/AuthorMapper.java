package com.lms.mapper;

import com.lms.dto.AuthorsDto;
import com.lms.dto.BooksDto;
import com.lms.entity.Author;
import com.lms.entity.Books;

public class AuthorMapper 
{
	public static AuthorsDto mapAuthorToDto(Author author)
	{
		return new AuthorsDto(author.getId(),author.getName(),author.getAwards());
	}
	
	public static Author mapAuthorsDtoToAuthor(AuthorsDto authordto)
	{
		
		return new Author(authordto.getName(),authordto.getAwards());
	}
}
