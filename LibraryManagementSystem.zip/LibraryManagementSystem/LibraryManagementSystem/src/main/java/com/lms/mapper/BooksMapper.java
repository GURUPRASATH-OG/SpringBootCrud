package com.lms.mapper;

import com.lms.dto.BooksDto;
import com.lms.entity.Books;

public class BooksMapper 
{
	public static BooksDto mapBooksToDto(Books book)
	{
		return new BooksDto(book.getId(),book.getAuthor().getId(),book.getTitle(),book.getGenre());
	}
	
	public static Books mapBooksDto(BooksDto bookdto)
	{
		Books books = new Books();
		books.setTitle(bookdto.getTitle());
		books.setGenre(bookdto.getGenre());
		return books;
	}
}
