package com.lms.exception;

public class BookNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4239338464663174928L;
	
	
	public BookNotFoundException(String msg) 
	{
		super(msg);
	}

}
