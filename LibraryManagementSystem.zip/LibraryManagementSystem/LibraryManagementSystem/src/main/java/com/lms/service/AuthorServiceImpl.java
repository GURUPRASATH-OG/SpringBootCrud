package com.lms.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lms.dto.AuthorWithBooksDto;
import com.lms.dto.AuthorsDto;
import com.lms.entity.Author;
import com.lms.entity.Books;
import com.lms.exception.AuthorNotFoundException;
import com.lms.mapper.AuthorMapper;
import com.lms.mapper.BooksMapper;
import com.lms.repository.AuthorRepository;
import com.lms.repository.BooksRepository;
@Repository
public class AuthorServiceImpl implements AuthorService 
{

	@Autowired
	private AuthorRepository repo;
	@Autowired 
	private BooksRepository bookrepo;
	@Override
	public AuthorsDto addAuthor(AuthorsDto authordto) 
	{
		    
	        Author addAuthor = AuthorMapper.mapAuthorsDtoToAuthor(authordto);
	        repo.save(addAuthor);
		    return AuthorMapper.mapAuthorToDto(addAuthor);
	}

	@Override
	public AuthorsDto getAuthorById(Long id) 
	{
		Author getauthor = repo.findById(id).orElseThrow(()->new AuthorNotFoundException("No Author found against the Given id:"+id));
		return AuthorMapper.mapAuthorToDto(getauthor);
	}

	@Override
	public AuthorsDto updateAuthor(Long id, AuthorsDto dto) 
	{
		Author fetchauthor = repo.findById(id).orElseThrow(()->new AuthorNotFoundException("No Author found against the Given id:"+id));
		Author updatedauthor = AuthorMapper.mapAuthorsDtoToAuthor(dto);
		updatedauthor.setId(fetchauthor.getId());//setting id so that recored will be updated
		updatedauthor = repo.save(updatedauthor);
		return AuthorMapper.mapAuthorToDto(updatedauthor);
	}

	@Override
	public void deleteAuthorById(Long id) {
		Author delauthor = repo.findById(id).orElseThrow(()->new AuthorNotFoundException("No Author found against the Given id:"+id));
		repo.deleteById(id);
		
	}

	@Override
	public void deleteAllAuthors() {
		 repo.deleteAll();
		
	}

	@Override
	public List<AuthorsDto> getAllAuthors() {
		List<Author> authorslist = repo.findAll();
		return authorslist.stream().map(AuthorMapper::mapAuthorToDto).collect(Collectors.toList());
	}

	@Override
	public AuthorWithBooksDto getallBooks(Long id) 
	{
		 // Fetch the author first
	    Author author = repo.findById(id)
	                        .orElseThrow(() -> new AuthorNotFoundException("No Author found with ID: " + id));
	    
	    // Fetch the list of books
	    List<Books> booksList = bookrepo.findByAuthor(author);
	    
	    AuthorWithBooksDto authorwithbooks = new AuthorWithBooksDto();
	    authorwithbooks.setId(author.getId());
	    authorwithbooks.setAward(author.getAwards());
	    authorwithbooks.setName(author.getName());
	    authorwithbooks.setBooks(booksList.stream().map(BooksMapper::mapBooksToDto).collect(Collectors.toList()));
	    return authorwithbooks;
	}

	
	
	


}
