package com.lms.exception;

public class AuthorNotFoundException extends RuntimeException 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6570263517365380903L;
	public AuthorNotFoundException(String msg)
	{
		super(msg);
	}

}
