package com.lms.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lms.dto.BooksDto;
import com.lms.entity.Author;
import com.lms.entity.Books;
import com.lms.exception.AuthorNotFoundException;
import com.lms.exception.BookNotFoundException;
import com.lms.mapper.BooksMapper;
import com.lms.repository.AuthorRepository;
import com.lms.repository.BooksRepository;

@Repository
public class BooksServiceImpl implements BooksService 
{
	@Autowired
	private BooksRepository repository;
	@Autowired AuthorRepository authorrepo;

	/*
	 * Mapping BooksDto to Books and saving Books in table 
	 * and Returning the saved Book after mapping it to DTO.
	 */
	@Override
	public BooksDto addBook(BooksDto dto)
	{
		Author author = authorrepo.findById(dto.getAuthor_id()).orElseThrow(()->new AuthorNotFoundException("no author found"));
		/* System.out.println(author); */
		Books savebook = BooksMapper.mapBooksDto(dto);
		savebook.setAuthor(author);
		repository.save(savebook);
		dto =BooksMapper.mapBooksToDto(savebook);
		
		return dto;
	}

	@Override
	public List<BooksDto> getAllBooks() 
	{
		
		List<Books> booklist = repository.findAll();
		return booklist.stream().map((book)->BooksMapper.mapBooksToDto(book)).collect(Collectors.toList());
		
	}

	@Override
	public BooksDto getBookByid(Long id) 
	{
		Books resultbook = repository.findById(id).orElseThrow(()->new BookNotFoundException("No book Found against the Given id:"+id)); 
		return BooksMapper.mapBooksToDto(resultbook);
	}

	@Override
	public BooksDto updateBook(Long id, BooksDto dto) 
	{
		Author author = authorrepo.findById(dto.getAuthor_id()).orElseThrow(()->new AuthorNotFoundException("no author found"));
		Books fetchbook_toUpdate = repository.findById(id).orElseThrow(()->new BookNotFoundException("No book Found against the Given id:"+id)); 
		fetchbook_toUpdate =BooksMapper.mapBooksDto(dto);
		fetchbook_toUpdate.setAuthor(author);
		fetchbook_toUpdate.setId(id);
		repository.save(fetchbook_toUpdate);	
		return BooksMapper.mapBooksToDto(fetchbook_toUpdate);
	}

	@Override
	public void deleteBook(Long id) 
	{
		Books deletebook=repository.findById(id).orElseThrow(()->new BookNotFoundException("No book Found against the Given id:"+id));
		repository.delete(deletebook);

	}

	@Override
	public void deleteAllBooks() 
	{
		repository.deleteAll();	
	}

}
