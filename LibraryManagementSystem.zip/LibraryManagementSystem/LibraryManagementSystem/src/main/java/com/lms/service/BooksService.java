package com.lms.service;

import java.util.List;

import com.lms.dto.BooksDto;

public interface BooksService 
{
	public BooksDto addBook(BooksDto dto);
	public List<BooksDto> getAllBooks();
	public BooksDto getBookByid(Long id);
	public BooksDto updateBook(Long id,BooksDto dto);
	public void deleteBook(Long id);
	public void deleteAllBooks();
	
}
