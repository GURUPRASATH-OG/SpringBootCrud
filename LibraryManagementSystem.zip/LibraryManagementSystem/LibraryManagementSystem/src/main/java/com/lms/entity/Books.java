package com.lms.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
//using Lombok lib for getter,setter,const.
@Getter
@Setter
@NoArgsConstructor

@ToString(includeFieldNames=true) //will include fields name in toString method.
@Entity
@Table(name="BooksDetail")
public class Books 
{
	/*
	 * Declaring this field as primary key and set it to auto-increment by @Id,@GeneratedValue.
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO) 
    @NotNull(message = "Book ID cannot be null")
	private Long id;
	@NotBlank(message="Title is required")
	private String title;
	@NotBlank(message = "Genere is required")
	private String genre;
	//Many books can be written by one author
	@ManyToOne
	@JsonBackReference 
    @NotNull(message = "Author ID cannot be null")
	private Author author;
	
	public Books(String title, String genre) {
		super();
		this.title = title;
		this.genre = genre;
	}
	
	
	
}
