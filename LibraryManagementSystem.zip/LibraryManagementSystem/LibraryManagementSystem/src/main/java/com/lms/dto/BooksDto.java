package com.lms.dto;

import org.springframework.stereotype.Component;
import com.lms.entity.Author;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//using Lombok lib for generating Getters,Setters,Constructors
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Component
public class BooksDto
{

	private Long book_id,author_id;
	private String title,genre;
	
}
