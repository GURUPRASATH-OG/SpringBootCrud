package com.lms.service;

import java.util.List;

import com.lms.dto.AuthorWithBooksDto;
import com.lms.dto.AuthorsDto;
import com.lms.dto.BooksDto;

public interface AuthorService 
{
	public AuthorsDto addAuthor(AuthorsDto authordto);
	public AuthorsDto getAuthorById(Long id);
	public List<AuthorsDto> getAllAuthors();
	public AuthorsDto updateAuthor(Long id,AuthorsDto dto);
	public void deleteAuthorById(Long id);
	public void deleteAllAuthors();
	public AuthorWithBooksDto getallBooks(Long id);
}
