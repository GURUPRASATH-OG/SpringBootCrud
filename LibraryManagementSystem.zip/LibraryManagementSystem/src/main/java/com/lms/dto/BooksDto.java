package com.lms.dto;

import org.springframework.stereotype.Component;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//using Lombok lib for generating Getters,Setters,Constructors
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Component
public class BooksDto
{

	
	private Long book_id;
	@NotBlank(message="author id is required")
	private Long author_id;
	@NotBlank(message="Title is required")
	private String title;
	@NotBlank(message="Genre is required")
	private String genre;
	
}
