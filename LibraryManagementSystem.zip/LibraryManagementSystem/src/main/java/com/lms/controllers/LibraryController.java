package com.lms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.dto.BooksDto;
import com.lms.service.BooksService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/books")
public class LibraryController 
{
	@Autowired
	private BooksService service;
	@Autowired
	private BooksDto bookdto;
	@PostMapping
	public ResponseEntity<BooksDto> createBook(@Valid @RequestBody BooksDto dto)
	{
		bookdto = service.addBook(dto);
		return new ResponseEntity<>(bookdto,HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<BooksDto>> getAllBooks()
	{
		List<BooksDto> listofAllBooks = service.getAllBooks();
		return new ResponseEntity<>(listofAllBooks,HttpStatus.OK);
	}
	
	@GetMapping("{id}")
	public ResponseEntity<BooksDto> getBookById(@Valid @PathVariable Long id)
	{
		bookdto = service.getBookByid(id);
		return new ResponseEntity<>(bookdto,HttpStatus.OK);
	}
	
	@PutMapping("{id}")
	public ResponseEntity<BooksDto> updateBook(@Valid @PathVariable Long id,@Valid @RequestBody BooksDto updatebook)
	{
		bookdto = service.updateBook(id, updatebook);
		return new ResponseEntity<>(bookdto,HttpStatus.OK);
	}
	@DeleteMapping("{id}")
	public ResponseEntity<List<BooksDto>> deleteBook(@Valid @PathVariable Long id)
	{
		service.deleteBook(id);
		return getAllBooks();
	}
	
	@DeleteMapping
	public ResponseEntity<String> Wipe()
	{
		service.deleteAllBooks();
		return new ResponseEntity<>("all books deleted",HttpStatus.OK);
	}
	
}
