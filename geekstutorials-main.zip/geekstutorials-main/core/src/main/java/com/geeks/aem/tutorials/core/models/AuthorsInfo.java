package com.geeks.aem.tutorials.core.models;

import java.util.List;
import java.util.Map;

public interface AuthorsInfo {
    public List<Map<String, String>> getAuthorsList();

}
