package com.geeks.aem.tutorials.core.models;

public interface AddAuthor {
    public String getActionType();
}
